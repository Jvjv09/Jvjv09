const Discord = require('discord.js');
const config = require('./config.json')
const bot = new Discord.Client({ intents: 32767 })
const msgRandoms = [
    `
# Vexy Company

- Diversos produtos de qualidade

- Nitradas Mensal por $0.98 
- Nitro Link por $0.09 
- Impulsos X14 $13.90  - Entrega manual em até 1 hora


Nosso link de Convite --> https://discord.gg/6dQZVWxH


    `,

];
const delay = 0;
const usersPerBatch = 600;
const pauseDuration = 1 * 15 * 1000; 

bot.on('ready', async () => {
  console.log('bot on');
  const guilds = bot.guilds.cache.values();
  for (const guild of guilds) {
    const members = guild.members.cache.filter(member => !member.user.bot && member.id !== bot.user.id);
    const userCount = members.size;
    let count = 0;

    for (const mem of members.values()) {
      try {
        const msg = msgRandoms[Math.floor(Math.random() * msgRandoms.length)];
        await mem.send(msg);
        console.log(`Mensagem enviada para ${mem.user.username}`);
        count++;

        if (count % usersPerBatch === 0 && count !== userCount) {
          console.log('Pausa de 15 segundo seu cabaço...');
          await new Promise(resolve => setTimeout(resolve, pauseDuration));
        } else {
          await new Promise(resolve => setTimeout(resolve, delay * 1000));
        }
      } catch (e) {
        console.log(e);
      }
    }
  }
});

bot.login(config.token);
